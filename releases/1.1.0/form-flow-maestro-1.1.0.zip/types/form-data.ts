/**
 * Form Data Types
 * Types related to form fields, captured data, and form filling
 */

import type { CapturedLabels } from "./constants";
import type { Country } from "./country";

export interface FormField {
  label?: CapturedLabels | string;
  name?: string;
  value: string;
}

export interface CapturedData {
  ssn: string;
  timestamp: number;
  allFields: Record<string, FormField>;
  country?: Country;
  environment?: string;
  scoring?: string;
  fieldsByName?: Record<string, string>;
}

export interface RawFormData {
  [key: string]: unknown;
  fields?: Record<string, FormField>;
  timestamp?: number;
  countryAbbrev?: string | null;
}

export interface FormFillRule {
  selector: string;
  value: string | ((data: CapturedData) => string);
  condition?: (data: CapturedData) => boolean;
  priority?: number;
}

export interface FormFillStrategy {
  name: string;
  urlPattern: RegExp;
  rules: FormFillRule[];
  setup?: () => void;
  cleanup?: () => void;
}
