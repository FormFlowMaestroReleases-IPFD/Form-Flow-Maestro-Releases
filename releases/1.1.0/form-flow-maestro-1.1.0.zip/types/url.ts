export const DATA_CAPTURE_URL = "aio-data-generator.nonprod.ipfdigital.io/generated-data";
export const LOCALHOST = "localhost";
