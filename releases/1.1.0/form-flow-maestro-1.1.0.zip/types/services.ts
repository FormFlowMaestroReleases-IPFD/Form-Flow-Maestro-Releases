/**
 * Service Types
 * Types for service responses and API interactions
 */

import type { Country } from "./country";

export interface CountryServiceResponse {
  countries: Country[];
}

export interface EnvScoringServiceResponse {
  environments: Record<string, string>;
  selectedEnvironment: string | null;
  scoringOptions: Record<string, string>;
  selectedScoring: string | null;
}
export interface UIEnvironmentOption {
  value: string;
  text: string;
  isSelected: boolean;
}

export interface UIScoringOption {
  value: string;
  text: string;
  isSelected: boolean;
}

export interface UIExtractedCountry extends Country {
  isActive: boolean;
}
