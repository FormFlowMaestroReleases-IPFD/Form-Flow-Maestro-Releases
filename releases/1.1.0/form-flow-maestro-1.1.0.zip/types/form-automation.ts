/**
 * Form Automation Types
 * Types for form automation rules and actions
 */

import type { Brands, CountriesAbbreviations, FormSteps, CapturedLabels } from "./constants";

export type AutomationAction =
  | "fill"
  | "fill_custom"
  | "click"
  | "click_first_dropdown_option"
  | "select"
  | "select_by_index"
  | "autocomplete_fill"
  | "autocomplete_select_by_text"
  | "autocomplete_select_by_index"
  | "autocomplete_select_by_value"
  | "check"
  | "uncheck"
  | "focus"
  | "scroll"
  | "wait"
  | "clear"
  | "remove_element"
  | "trigger_event";

export type ActionOptions = {
  timeToWaitForElementToAppear?: number;
  timeout?: number;
  retryCount?: number;
};

export interface BaseFieldAction {
  targetSelector?: string;
  targetId?: string;
  targetClass?: string;
  targetText?: string;
  targetPlaceholder?: string;
  copyFromSelector?: string;

  condition?: {
    element?: string;
    value?: string;
    visible?: boolean;
  };

  options?: ActionOptions;
}
interface BaseFillAction extends BaseFieldAction {
  value: string;
}

export interface FillAction extends BaseFieldAction {
  action: AutomationAction;
  value?: string;
}

export interface FillCustomAction extends BaseFillAction {
  action: "fill_custom";
}

export interface ClickAction extends BaseFieldAction {
  action: "click";
}

export interface ClickFirstDropdownOptionAction extends BaseFieldAction {
  action: "click_first_dropdown_option";
}

export interface RemoveElementAction extends BaseFieldAction {
  action: "remove_element";
}

// Base interface for select actions
interface BaseSelectAction extends BaseFieldAction {
  value: string;
}

export interface SelectAction extends BaseSelectAction {
  action: "select";
}

export interface SelectByIndexAction extends BaseFieldAction {
  action: "select_by_index";
  index: number;
}

// Base interface for all autocomplete actions
interface BaseAutocompleteAction extends BaseFieldAction {
  autocompleteDropdownContainer: string;
  autocompleteItemSelector: string;
}

export interface AutocompleteFillAction extends BaseAutocompleteAction {
  action: "autocomplete_fill";
  textToType: string;
}

export interface AutocompleteSelectByTextAction extends BaseAutocompleteAction {
  action: "autocomplete_select_by_text";
  textToMatch: string;
}

export interface AutocompleteSelectByIndexAction extends BaseAutocompleteAction {
  action: "autocomplete_select_by_index";
  index: number;
}

export interface AutocompleteSelectByValueAction extends BaseAutocompleteAction {
  action: "autocomplete_select_by_value";
  valueToMatch: string;
}

export interface CheckAction extends BaseFieldAction {
  action: "check";
}

export interface UncheckAction extends BaseFieldAction {
  action: "uncheck";
}

export interface FocusAction extends BaseFieldAction {
  action: "focus";
}

export interface ScrollAction extends BaseFieldAction {
  action: "scroll";
}

export interface WaitAction extends BaseFieldAction {
  action: "wait";
}

export interface ClearAction extends BaseFieldAction {
  action: "clear";
}

export interface TriggerEventAction extends BaseFieldAction {
  action: "trigger_event";
  eventType: string;
}
export type FieldAction =
  | FillAction
  | FillCustomAction
  | ClickAction
  | ClickFirstDropdownOptionAction
  | RemoveElementAction
  | SelectAction
  | SelectByIndexAction
  | AutocompleteFillAction
  | AutocompleteSelectByTextAction
  | AutocompleteSelectByIndexAction
  | AutocompleteSelectByValueAction
  | CheckAction
  | UncheckAction
  | FocusAction
  | ScrollAction
  | WaitAction
  | ClearAction
  | TriggerEventAction;

type StrictFormStepRules = {
  [K in CapturedLabels]?: FieldAction;
} & {
  CUSTOM_ACTIONS?: FieldAction[];
};

export type FormStepRules = StrictFormStepRules;

export type CountryRules = Partial<Record<FormSteps, FormStepRules>>;

export type BrandRules = Partial<Record<CountriesAbbreviations, CountryRules>>;

export type CompanyRules = Partial<Record<Brands, BrandRules>>;

export type FormAutomationRules = CompanyRules;
