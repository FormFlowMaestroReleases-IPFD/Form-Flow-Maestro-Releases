/**
 * DOM Utility Types
 * Types for DOM manipulation and utilities
 */

export interface SelectorConfig {
  selector: string;
  timeout?: number;
  required?: boolean;
  attribute?: string;
}

export interface ModalOptions {
  title?: string;
  content: string;
  buttons?: Array<{
    text: string;
    action: () => void;
    className?: string;
  }>;
  className?: string;
  closeOnBackdrop?: boolean;
  closeOnEscape?: boolean;
}
