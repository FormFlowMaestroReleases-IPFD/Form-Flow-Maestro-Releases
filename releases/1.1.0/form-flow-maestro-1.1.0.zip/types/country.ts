/**
 * Country Types
 * This file contains types specifically for country-related functionality
 */

import { CountriesAbbreviations } from "./constants";

export interface Country {
  name: string;
  abbreviation: CountriesAbbreviations;
}

export interface CountryConfiguration {
  environment?: {
    all: Record<string, string>;
    selected: string | null;
  };
  scoring?: {
    all: Record<string, string>;
    selected: string | null;
  };
}

export const COUNTRIES: Record<CountriesAbbreviations, Country> = {
  [CountriesAbbreviations.au]: {
    name: "Australia",
    abbreviation: CountriesAbbreviations.au,
  },
  [CountriesAbbreviations.cz]: {
    name: "Czech",
    abbreviation: CountriesAbbreviations.cz,
  },
  [CountriesAbbreviations.ee]: {
    name: "Estonia",
    abbreviation: CountriesAbbreviations.ee,
  },
  [CountriesAbbreviations.hu]: {
    name: "Hungary",
    abbreviation: CountriesAbbreviations.hu,
  },
  [CountriesAbbreviations.lt]: {
    name: "Lithuania",
    abbreviation: CountriesAbbreviations.lt,
  },
  [CountriesAbbreviations.lv]: {
    name: "Latvia",
    abbreviation: CountriesAbbreviations.lv,
  },
  [CountriesAbbreviations.mx]: {
    name: "Mexico",
    abbreviation: CountriesAbbreviations.mx,
  },
  [CountriesAbbreviations.pl]: {
    name: "Poland",
    abbreviation: CountriesAbbreviations.pl,
  },
  [CountriesAbbreviations.ro]: {
    name: "Romania",
    abbreviation: CountriesAbbreviations.ro,
  },
};
