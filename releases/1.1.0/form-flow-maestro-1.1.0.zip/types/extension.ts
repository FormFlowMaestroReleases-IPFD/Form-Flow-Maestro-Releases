/**
 * Extension Types
 * Types for Chrome extension lifecycle and Chrome-specific functionality
 */

import type { Brands } from "./constants";
import type { MuleInjectionHandler } from "../page-controller-modular";

export type IconStatus = "neutral" | "success" | "warning" | "error";

export interface TabInfo {
  id: number;
  url: string;
  active: boolean;
}

export interface ExtensionManager {
  init(): Promise<void>;
  cleanup(): void;
}

export interface ExtensionError {
  code: string;
  message: string;
  context?: Record<string, unknown>;
  timestamp: number;
}

export interface ExtensionEvent {
  type: string;
  payload: unknown;
  timestamp: number;
  source: "popup" | "content" | "background";
}

export interface ExtendedTab extends chrome.tabs.Tab {
  muleMetadata?: {
    lastFillAttempt?: number;
    fillHistory: Array<{
      timestamp: number;
      success: boolean;
      fields: number;
    }>;
    brand?: Brands;
  };
}

declare global {
  interface Window {
    muleInjectionHandler?: MuleInjectionHandler;
    muleExtensionDebug?: boolean;
    FormAutomationConstants?: any;
  }
}

export interface IconPaths extends Record<number, string> {
  "16": string;
  "48": string;
  "128": string;
}
