/**
 * Validation and Utility Types
 * Types for validation, performance monitoring, and utility functions
 */

import type { PluginConfig } from "./storage";
export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export interface ConfigValidator {
  validate(config: Partial<PluginConfig>): ValidationResult;
}

export interface PerformanceMetric {
  name: string;
  value: number;
  unit: string;
  timestamp: number;
}

export interface PerformanceReport {
  metrics: PerformanceMetric[];
  duration: number;
  success: boolean;
}

export interface CustomRule {
  id: string;
  name: string;
  description?: string;
  match: {
    url: string;
    textIdentifier?: string;
    selector: string;
  };
  action: {
    type: "fill" | "click" | "wait";
    value?: string;
    delay?: number;
  };
  enabled: boolean;
  priority: number;
  createdAt: number;
  updatedAt: number;
}

export interface CustomRuleEngine {
  addRule(rule: CustomRule): void;
  removeRule(id: string): void;
  updateRule(id: string, updates: Partial<CustomRule>): void;
  executeRules(url: string, context: unknown): Promise<void>;
  validateRule(rule: CustomRule): ValidationResult;
}
