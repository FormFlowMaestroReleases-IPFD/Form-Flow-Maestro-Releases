/**
 * Configuration Constants
 * Additional constants for configuration and environment settings
 */
export const ENVIRONMENTS = {
  SIT: "SIT",
  UAT: "UAT",
  ST02: "ST02",
  ST03: "ST03",
  ST04: "ST04",
  ST05: "ST05",
  ST06: "ST06",
  ST07: "ST07",
  ST08: "ST08",
  ST09: "ST09",
  ST10: "ST10",
  ST11: "ST11",
  ST12: "ST12",
  ST13: "ST13",
  DEMO: "DEMO",
} as const;

export type Environment = keyof typeof ENVIRONMENTS;

export const SCORING_OPTIONS = {
  S: "S",
  "A+": "A+",
  A: "A",
  B: "B",
  "C+": "C+",
  C: "C",
  D: "D",
  E: "E",
  "E-": "E-",
} as const;

export type ScoringOption = keyof typeof SCORING_OPTIONS;

export const POLAND_SCORING_OPTIONS = {
  "Score 475": "SCORE_475",
  "Score 465": "SCORE_465",
  "Score 455": "SCORE_455",
  "Score 445": "SCORE_445",
  "Score 435": "SCORE_435",
} as const;

export type PolandScoringOption = keyof typeof POLAND_SCORING_OPTIONS;
