/**
 * Storage Types
 * Types for Chrome extension storage and configuration
 */

import type { Brands, CountriesAbbreviations } from "./constants";
import type { Country } from "./country";
import type { CapturedData } from "./form-data";
export interface PluginConfig {
  country: Country;
  environment?: string;
  scoring?: string;
  countryAbbrev?: CountriesAbbreviations;
}

export interface StorageData {
  config?: PluginConfig;
  capturedData?: CapturedData | null;
  brand?: Brands;
  lastUpdated?: number;
}
