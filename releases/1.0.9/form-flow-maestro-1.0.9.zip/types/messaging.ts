/**
 * Messaging Types
 * Types for Chrome extension messaging system
 */

export interface MessagePayload {
  action: string;
  [key: string]: unknown;
}

export interface MessageResponse {
  success?: boolean;
  error?: string;
  [key: string]: unknown;
}

export type MessageHandler = (
  message: MessagePayload,
  sender?: chrome.runtime.MessageSender
) => MessageResponse | Promise<MessageResponse>;

export type MessageAction =
  | "GET_CONFIG"
  | "UPDATE_CONFIG"
  | "CONFIG_UPDATED"
  | "GET_COUNTRIES"
  | "GET_ENV_SCORING"
  | "START_CAPTURE"
  | "STOP_CAPTURE"
  | "CAPTURE_FORM_DATA"
  | "DATA_CAPTURED"
  | "GET_CAPTURED_DATA"
  | "CLEAR_DATA"
  | "CAPTURE_UPDATED"
  | "CHECK_AND_FILL_FORM"
  | "TOGGLE_PAUSE_FILLING"
  | "BRAND_CHANGED"
  | "GET_BRAND"
  | "UPDATE_EXTENSION_ICON"
  | "SAVE_COLLAPSED_STATE"
  | "SSN_VALUE_CHANGED"
  | "TEST_COMMUNICATION";
