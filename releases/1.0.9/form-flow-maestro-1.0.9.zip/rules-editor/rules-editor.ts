import { ACTION_EXAMPLES } from "./constants";
import { FORM_AUTOMATION_RULES as BUILT_IN_DEFAULT_RULES } from "../modules/common/config/constants/form-automation-rules";
import { AnimationManager } from "../modules/config/animation-manager";
import { FileManager } from "../modules/config/file-manager";
import { MonacoManager } from "../modules/config/monaco-manager";
import { RulesManager } from "../modules/config/rules-manager";
import { ConfigUIManager } from "../modules/config/ui-manager";

class RulesConfigManager {
  private monacoManager: MonacoManager;
  private rulesManager: RulesManager;
  private uiManager: ConfigUIManager;
  private fileManager: FileManager;
  private animationManager: AnimationManager;

  constructor() {
    this.monacoManager = new MonacoManager();
    this.rulesManager = new RulesManager();
    this.uiManager = new ConfigUIManager();
    this.fileManager = new FileManager();
    this.animationManager = new AnimationManager();

    this.init();
  }

  async init(): Promise<void> {
    await this.loadLayoutFragments();
    this.setupEventListeners();
    await this.loadDefaultRules();
    await this.loadCurrentRules();
    await this.waitForEditorContainers();
    await this.initializeMonacoEditor();
    this.updateUI();
    this.checkConstantsLoaded();
  }

  setupEventListeners(): void {
    this.uiManager.setupEventListeners();

    (document.getElementById("load-defaults") as HTMLButtonElement)?.addEventListener("click", () =>
      this.loadDefaultRules()
    );
    (document.getElementById("save-rules") as HTMLButtonElement)?.addEventListener("click", () =>
      this.saveRules()
    );
    (document.getElementById("reset-rules") as HTMLButtonElement)?.addEventListener("click", () =>
      this.resetToDefaults()
    );

    (document.getElementById("export-rules") as HTMLButtonElement)?.addEventListener("click", () =>
      this.exportRules()
    );
    (document.getElementById("export-defaults") as HTMLButtonElement)?.addEventListener(
      "click",
      () => this.exportDefaultRules()
    );
    (document.getElementById("file-input") as HTMLInputElement)?.addEventListener("change", e =>
      this.handleFileImport(e)
    );

    document.addEventListener("triggerLaserAnimation", () => {
      this.animationManager.shootLasers();
    });

    document.addEventListener("ensureExamplesEditor", () => {
      this.monacoManager.ensureExamplesEditor();
    });

    document.addEventListener("updateExample", (event: Event) => {
      const customEvent = event as CustomEvent;
      const action = customEvent.detail?.action || "fill";
      this.updateExample(action);
    });
  }

  async initializeMonacoEditor(): Promise<void> {
    await this.monacoManager.initializeMonacoEditor();
  }

  private async loadLayoutFragments(): Promise<void> {
    const load = async (containerId: string, filePath: string): Promise<void> => {
      const res = await fetch(filePath);
      const html = await res.text();
      const container = document.getElementById(containerId);
      if (container) {
        container.innerHTML = html;
      }
    };

    await Promise.all([
      load("header-container", "rules-editor/header.html"),
      load("navigation-container", "rules-editor/navigation.html"),
      load("editor-container", "rules-editor/editor-section.html"),
      load("import-export-container", "rules-editor/import-export-section.html"),
      load("documentation-container", "rules-editor/documentation.html"),
      load("user-guide-container", "rules-editor/user-guide.html"),
    ]);
    await this.injectValidationLogger();
  }

  private async waitForEditorContainers(): Promise<void> {
    const exists = () =>
      document.getElementById("monaco-editor") &&
      document.getElementById("editor-row") &&
      document.getElementById("monaco-action-snippet");

    if (exists()) {
      return;
    }

    await new Promise<void>(resolve => {
      const observer = new MutationObserver(() => {
        if (exists()) {
          observer.disconnect();
          resolve();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    });
  }

  private async injectValidationLogger(): Promise<void> {
    const logHost = document.getElementById("error-log");
    if (!logHost) {
      return;
    }

    let collapsed = true;
    const headerBtn = logHost.querySelector("#toggle-error-log-btn") as HTMLButtonElement | null;
    if (headerBtn) {
      const errorCount = 0;
      const setLabel = (): void => {
        if (errorCount === 0) {
          headerBtn.textContent = "No errors";
          headerBtn.disabled = true;
          headerBtn.setAttribute("aria-expanded", "false");
          headerBtn.setAttribute("disabled", "true");
          logHost.classList.add("collapsed");
        } else {
          headerBtn.disabled = false;
          headerBtn.textContent = collapsed ? "Expand" : "Collapse";
          headerBtn.setAttribute("aria-expanded", String(!collapsed));
        }
      };
      setLabel();
      headerBtn.addEventListener("click", () => {
        collapsed = !collapsed;
        logHost.classList.toggle("collapsed", collapsed);
        setLabel();
      });
    }

    const body = logHost.querySelector(".error-log-body");
    if (!body) {
      return;
    }

    let logCounter = 0;
    let totalErrors = 0;

    const extractMethodFromMessage = (msg: string): string | undefined => {
      const m = msg.match(/^\[rules-validation\]\s*\[([^\]]+)\]\s*/i);
      return m?.[1];
    };

    const getCallerName = (): string | undefined => {
      try {
        throw new Error();
      } catch (e: unknown) {
        const stack = (e as Error).stack || "";
        const lines = stack.split("\n").map(l => l.trim());
        for (const line of lines.slice(2)) {
          if (/rules-editor\/.+/.test(line)) {
            continue;
          }
          const match = line.match(/^at\s+([^\s(]+).*$/);
          const name = match?.[1];
          if (
            name &&
            name !== "console.error" &&
            name !== "console.warn" &&
            name !== "logInvalid"
          ) {
            return name;
          }
        }
      }
      return undefined;
    };

    const append = (
      type: "error" | "warn",
      message: string,
      meta?: Record<string, unknown>,
      methodName?: string
    ) => {
      const item = document.createElement("div");
      item.className = "error-item";

      const when = new Date().toLocaleTimeString();
      const rawFirstLine = (message || "").split("\n")[0] || String(message);
      const headline = rawFirstLine.replace(/^\[rules-validation\]\s*(\[[^\]]+\]\s*)?/i, "").trim();

      const indexDiv = document.createElement("span");
      indexDiv.className = "error-index";
      indexDiv.textContent = `${++logCounter}.`;

      const content = document.createElement("div");
      content.className = "error-content";

      const header = document.createElement("div");
      header.className = "error-meta";
      const resolvedMethod = methodName || extractMethodFromMessage(rawFirstLine) || undefined;
      if (resolvedMethod) {
        const methodSpan = document.createElement("span");
        methodSpan.className = "error-method";
        methodSpan.textContent = `[${resolvedMethod}]`;
        header.appendChild(indexDiv);
        header.appendChild(methodSpan);
      } else {
        header.appendChild(indexDiv);
      }
      const msgSpan = document.createElement("span");
      msgSpan.className = "error-headline";
      msgSpan.textContent = headline;
      const timeSpan = document.createElement("span");
      timeSpan.className = "error-time";
      timeSpan.textContent = `[${when}]`;
      header.appendChild(msgSpan);
      header.appendChild(timeSpan);
      header.setAttribute("role", "button");
      header.setAttribute("tabindex", "0");

      const details = document.createElement("div");
      details.className = "error-details";
      item.classList.add("collapsed");
      const pre = document.createElement("pre");
      const rest = (message || "").split("\n").slice(1).join("\n").trim();
      pre.textContent = (rest ? rest + "\n" : "") + (meta ? JSON.stringify(meta, null, 2) : "");
      details.appendChild(pre);

      header.addEventListener("click", () => {
        item.classList.toggle("collapsed");
      });
      header.addEventListener("keydown", e => {
        if ((e as KeyboardEvent).key === "Enter" || (e as KeyboardEvent).key === " ") {
          e.preventDefault();
          item.classList.toggle("collapsed");
        }
      });

      content.appendChild(header);
      content.appendChild(details);
      item.appendChild(content);
      (body as HTMLElement).appendChild(item);
      (body as HTMLElement).scrollTop = (body as HTMLElement).scrollHeight;

      totalErrors++;
      if (headerBtn) {
        if (totalErrors === 1) {
          collapsed = false;
          logHost.classList.remove("collapsed");
        }
        errorCount = totalErrors;
        setLabel();
      }
    };

    const originalError = console.error.bind(console);
    const originalWarn = console.warn.bind(console);

    console.error = (...args: unknown[]) => {
      try {
        if (typeof args[0] === "string" && args[0].toString().startsWith("[rules-validation]")) {
          const msg = String(args[0]);
          const method = extractMethodFromMessage(msg) || getCallerName();
          append("error", msg, (typeof args[1] === "object" && args[1]) as any, method);
        }
      } catch {
        /* noop */
      }
      originalError(...(args as any));
    };

    console.warn = (...args: unknown[]) => {
      try {
        if (typeof args[0] === "string" && args[0].toString().startsWith("[rules-validation]")) {
          const msg = String(args[0]);
          const method = extractMethodFromMessage(msg) || getCallerName();
          append("warn", msg, (typeof args[1] === "object" && args[1]) as any, method);
        }
      } catch {
        /* noop */
      }
      originalWarn(...(args as any));
    };
  }

  async loadDefaultRules(): Promise<void> {
    try {
      const defaults = await this.rulesManager.loadDefaultRules(BUILT_IN_DEFAULT_RULES);
      this.uiManager.showStatus("raw-editor-status", "defaults load!", "success");

      if (this.monacoManager.getEditor()) {
        this.monacoManager.setEditorValue(this.monacoManager.generateTypeScriptCode(defaults));
      }
    } catch (error: any) {
      this.uiManager.showStatus("raw-editor-status", error.message, "error");
    }
  }

  async loadCurrentRules(): Promise<void> {
    try {
      await this.rulesManager.loadCurrentRules();
    } catch (error: any) {
      this.uiManager.showStatus("raw-editor-status", error.message, "error");
    }
  }

  async saveRules(): Promise<void> {
    try {
      const code = this.monacoManager.getEditorValue();
      const rules = this.rulesManager.extractRulesFromCode(code);
      const validationResult = this.rulesManager.validateRulesStructure(rules);
      if (!validationResult.isValid) {
        this.uiManager.showStatus(
          "raw-editor-status",
          `Cannot save: ${validationResult.errors.join(", ")}`,
          "error"
        );
        return;
      }
      await this.rulesManager.saveRules(rules);
      this.uiManager.showStatus("raw-editor-status", "save!", "success");
    } catch (error: any) {
      this.uiManager.showStatus("raw-editor-status", error.message, "error");
    }
  }

  async resetToDefaults(): Promise<void> {
    if (
      confirm(
        `Are you sure you want to reset to default rules?\nThis will load defaults to editor and overwrite \nyour custom rules in localStorage.`
      )
    ) {
      try {
        await this.rulesManager.resetToDefaults();
        if (this.monacoManager.getEditor()) {
          this.monacoManager.setEditorValue(
            this.monacoManager.generateTypeScriptCode(this.rulesManager.getCurrentRules())
          );
        }
        this.uiManager.showStatus("raw-editor-status", "reset!", "success");
      } catch (error: any) {
        this.uiManager.showStatus("raw-editor-status", error.message, "error");
      }
    }
  }

  exportRules(): void {
    this.fileManager.exportRules(this.rulesManager.getCurrentRules());
    this.uiManager.showStatus("import-export-status", "Rules exported!", "success");
  }

  exportDefaultRules(): void {
    this.fileManager.exportDefaultRules(this.rulesManager.getDefaultRules());
    this.uiManager.showStatus("import-export-status", "Default rules exported!", "success");
  }

  async handleFileImport(event: Event): Promise<void> {
    try {
      const rules = await this.fileManager.handleFileImport(event);
      const validationResult = this.rulesManager.validateRulesStructure(rules);
      if (validationResult.isValid) {
        this.rulesManager.saveRules(rules);
        if (this.monacoManager.getEditor()) {
          this.monacoManager.setEditorValue(this.monacoManager.generateTypeScriptCode(rules));
        }
        this.uiManager.showStatus("import-export-status", "File imported!", "success");
      } else {
        this.uiManager.showStatus(
          "import-export-status",
          "Invalid rules structure in imported file",
          "error"
        );
      }
    } catch (error: any) {
      this.uiManager.showStatus("import-export-status", error.message, "error");
    }
  }

  updateUI(): void {
    if (this.monacoManager.getEditor() && this.rulesManager.getCurrentRules()) {
      this.monacoManager.setEditorValue(
        this.monacoManager.generateTypeScriptCode(this.rulesManager.getCurrentRules())
      );
    }
  }

  checkConstantsLoaded(): void {
    this.uiManager.checkConstantsLoaded();
  }

  updateExample(action: string): void {
    const examplesEditor = this.monacoManager.getExamplesEditor();
    if (!examplesEditor) {
      return;
    }

    examplesEditor.setValue(this.getExampleCode(action));
  }

  private getExampleCode(action: string): string {
    const header = "import { FieldAction, FormAutomationRules } from '@types';\n\n";
    const examples = ACTION_EXAMPLES;

    return header + (examples[action] || examples["fill"]);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  new RulesConfigManager();
});
