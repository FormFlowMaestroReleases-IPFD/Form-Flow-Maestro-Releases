/**
 * Action Examples Constants
 * Code examples for different automation actions
 */

export const ACTION_EXAMPLES: Record<string, string> = {
  fill: `const example: Record<string, FieldAction> = {\n  "First Name": { action: "fill", targetSelector: "input[name='firstName']" }\n};`,
  fill_custom: `const example: Record<string, FieldAction> = {\n  "Promo Code": { action: "fill", targetSelector: "input[name='promo']", value: "DISCOUNT10" }\n};`,
  click: `const example: FieldAction = { action: "click", targetSelector: "button#submit" };`,
  select: `const example: FieldAction = { action: "select", targetSelector: "select#country", value: "cz" };`,
  select_by_index: `const example: FieldAction = { action: "select", targetSelector: "select#month", index: 1 };`,
  autocomplete_fill: `const example: FieldAction = { action: "autocomplete_fill", targetSelector: "input[name='city']", value: "Praha", dropdownSelector: ".list", itemSelector: ".item" };`,
  autocomplete_select_by_text: `const example: FieldAction = { action: "autocomplete_select_by_text", targetSelector: "input[name='city']", value: "Praha", dropdownSelector: ".list", itemSelector: ".item" };`,
  autocomplete_select_by_index: `const example: FieldAction = { action: "autocomplete_select_by_index", targetSelector: "input[name='city']", index: 0, dropdownSelector: ".list", itemSelector: ".item" };`,
  autocomplete_select_by_value: `const example: FieldAction = { action: "autocomplete_select_by_value", targetSelector: "input[name='city']", value: "123", dropdownSelector: ".list", itemSelector: ".item" };`,
  check: `const example: FieldAction = { action: "check", targetSelector: "#agree" };`,
  uncheck: `const example: FieldAction = { action: "uncheck", targetSelector: "#agree" };`,
  focus: `const example: FieldAction = { action: "focus", targetSelector: "#email" };`,
  scroll: `const example: FieldAction = { action: "scroll", targetSelector: "#footer" };`,
  wait: `const example: FieldAction = { action: "wait", targetSelector: "#async", options: { timeout: 2000 } };`,
  clear: `const example: FieldAction = { action: "clear", targetSelector: "#email" };`,
  remove_element: `const example: FieldAction = { action: "remove_element", targetSelector: "#ad" };`,
  trigger_event: `const example: FieldAction = { action: "trigger_event", targetSelector: "#input", eventType: "change" };`,
};
