/**
 * Form Automation Types
 * Types for form automation rules and actions
 */

import type { Brands, CountriesAbbreviations, FormSteps, CapturedLabels } from "./constants";

export type AutomationAction =
  | "fill"
  | "fill_custom"
  | "click"
  | "click_first_dropdown_option"
  | "select"
  | "select_by_index"
  | "autocomplete_fill"
  | "autocomplete_select_by_text"
  | "autocomplete_select_by_index"
  | "autocomplete_select_by_value"
  | "check"
  | "uncheck"
  | "focus"
  | "scroll"
  | "wait"
  | "clear"
  | "remove_element"
  | "trigger_event";

export type ActionOptions = {
  elementSearchTimeout?: number;
  visibilityTimeout?: number;
  retryCount?: number;
};

type TargetingStrategies = {
  targetSelector?: string;
  targetId?: string;
  targetClass?: string;
  targetText?: string;
  targetPlaceholder?: string;
  copyFromSelector?: string;
};

type RequireAtLeastOne<T, Keys extends keyof T = keyof T> = Pick<T, Exclude<keyof T, Keys>> &
  {
    [K in Keys]-?: Required<Pick<T, K>> & Partial<Pick<T, Exclude<Keys, K>>>;
  }[Keys];

export type BaseFieldAction = RequireAtLeastOne<TargetingStrategies> &
  TargetingStrategies & {
    condition?: {
      element?: string;
      value?: string;
      visible?: boolean;
    };

    options?: ActionOptions;
  };
type BaseFillAction = BaseFieldAction & {
  value: string;
};

export type FillAction = BaseFieldAction & {
  action: AutomationAction;
  value?: string;
};

export type FillCustomAction = BaseFillAction & {
  action: "fill_custom";
};

export type ClickAction = BaseFieldAction & {
  action: "click";
};

export type ClickFirstDropdownOptionAction = BaseFieldAction & {
  action: "click_first_dropdown_option";
};

export type RemoveElementAction = BaseFieldAction & {
  action: "remove_element";
};

type BaseSelectAction = BaseFieldAction & {
  value: string;
};

export type SelectAction = BaseSelectAction & {
  action: "select";
};

export type SelectByIndexAction = BaseFieldAction & {
  action: "select_by_index";
  index: number;
};

type BaseAutocompleteAction = BaseFieldAction & {
  autocompleteDropdownContainer: string;
  autocompleteItemSelector: string;
};

export type AutocompleteFillAction = BaseAutocompleteAction & {
  action: "autocomplete_fill";
  textToType: string;
};

export type AutocompleteSelectByTextAction = BaseAutocompleteAction & {
  action: "autocomplete_select_by_text";
  textToMatch: string;
};

export type AutocompleteSelectByIndexAction = BaseAutocompleteAction & {
  action: "autocomplete_select_by_index";
  index: number;
};

export type AutocompleteSelectByValueAction = BaseAutocompleteAction & {
  action: "autocomplete_select_by_value";
  valueToMatch: string;
};

export type CheckAction = BaseFieldAction & {
  action: "check";
};

export type UncheckAction = BaseFieldAction & {
  action: "uncheck";
};

export type FocusAction = BaseFieldAction & {
  action: "focus";
};

export type ScrollAction = BaseFieldAction & {
  action: "scroll";
};

export type WaitAction = BaseFieldAction & {
  action: "wait";
};

export type ClearAction = BaseFieldAction & {
  action: "clear";
};

export type TriggerEventAction = BaseFieldAction & {
  action: "trigger_event";
  eventType: string;
};
export type FieldAction =
  | FillAction
  | FillCustomAction
  | ClickAction
  | ClickFirstDropdownOptionAction
  | RemoveElementAction
  | SelectAction
  | SelectByIndexAction
  | AutocompleteFillAction
  | AutocompleteSelectByTextAction
  | AutocompleteSelectByIndexAction
  | AutocompleteSelectByValueAction
  | CheckAction
  | UncheckAction
  | FocusAction
  | ScrollAction
  | WaitAction
  | ClearAction
  | TriggerEventAction;

type StrictFormStepRules = {
  [K in CapturedLabels]?: FieldAction;
} & {
  CUSTOM_ACTIONS?: FieldAction[];
};

export type FormStepRules = StrictFormStepRules;

export type CountryRules = Partial<Record<FormSteps, FormStepRules>>;

export type BrandRules = Partial<Record<CountriesAbbreviations, CountryRules>>;

export type CompanyRules = Partial<Record<Brands, BrandRules>>;

export type FormAutomationRules = CompanyRules;

export type CapturedAction = FieldAction & {
  capturedLabel: string;
};

export interface Rule {
  urlPattern?: string;
  brand?: string | string[];
  country?: string | string[];
  captureBasedActions?: CapturedAction[];
  standaloneActions?: FieldAction[];
}

export type Rules = Rule[];
