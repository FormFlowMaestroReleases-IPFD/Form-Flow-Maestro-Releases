import { ACTION_EXAMPLES } from "./constants";
import { AUTOMATION_ACTIONS } from "../modules/common/config/constants";
import { UI_EVENTS, DOM_EVENT_NAMES } from "../modules/common/constants";
import { AnimationManager } from "../modules/config/animation-manager";
import { FileManager } from "../modules/config/file-manager";
import { MonacoManager } from "../modules/config/monaco-manager";
import { RulesManager } from "../modules/config/rules-manager";
import { ConfigUIManager } from "../modules/config/ui-manager";

class RulesConfigManager {
  private monacoManager: MonacoManager;
  private rulesManager: RulesManager;
  private uiManager: ConfigUIManager;
  private fileManager: FileManager;
  private animationManager: AnimationManager;

  constructor() {
    this.monacoManager = new MonacoManager();
    this.rulesManager = new RulesManager();
    this.uiManager = new ConfigUIManager();
    this.fileManager = new FileManager();
    this.animationManager = new AnimationManager();

    this.init();
  }

  async init(): Promise<void> {
    await this.loadLayoutFragments();
    this.setupEventListeners();
    await this.loadDefaultRules();
    await this.loadCurrentRules();
    await this.waitForEditorContainers();
    await this.initializeMonacoEditor();
    this.updateUI();
    this.checkConstantsLoaded();
    this.setupBeforeUnloadWarning();
    setTimeout(() => {
      this.uiManager.handleHashNavigation();
    }, 200);
  }

  private setupBeforeUnloadWarning(): void {
    window.addEventListener("beforeunload", (event: BeforeUnloadEvent) => {
      if (this.monacoManager.hasUnsavedChanges()) {
        event.preventDefault();
        event.returnValue = "";
      }
    });
  }

  private setupTabSwitchWarning(): void {
    document.querySelectorAll(".nav-tab").forEach(tab => {
      tab.addEventListener(
        DOM_EVENT_NAMES.CLICK,
        (e: Event) => {
          const targetTab = (e.target as HTMLElement).dataset["tab"];
          if (!targetTab) {
            return;
          }

          const currentTab = document.querySelector(".nav-tab.active")?.getAttribute("data-tab");
          if (currentTab === "raw-editor" && targetTab !== "raw-editor") {
            if (this.monacoManager.hasUnsavedChanges()) {
              const confirmed = confirm(
                "You have unsaved changes in the rules editor. Are you sure you want to switch tabs? Your changes will be lost if you don't save them."
              );
              if (!confirmed) {
                e.preventDefault();
                e.stopImmediatePropagation();
                return;
              }
            }
          }
        },
        true
      );
    });

    window.addEventListener(DOM_EVENT_NAMES.HASHCHANGE, () => {
      const currentTab = document.querySelector(".nav-tab.active")?.getAttribute("data-tab");
      const hash = window.location.hash.slice(1);
      const tabMap: Record<string, string> = {
        documentation: "help",
        editor: "raw-editor",
        "user-guide": "user-guide",
      };
      const targetTab = tabMap[hash] || null;

      if (currentTab === "raw-editor" && targetTab && targetTab !== "raw-editor") {
        if (this.monacoManager.hasUnsavedChanges()) {
          const confirmed = confirm(
            "You have unsaved changes in the rules editor. Are you sure you want to switch tabs? Your changes will be lost if you don't save them."
          );
          if (!confirmed) {
            const hashMap: Record<string, string> = {
              help: "documentation",
              "raw-editor": "editor",
              "user-guide": "user-guide",
            };
            window.history.replaceState(null, "", `#${hashMap[currentTab] || "editor"}`);
            return;
          }
        }
      }
    });
  }

  setupEventListeners(): void {
    this.uiManager.setupEventListeners();
    this.setupTabSwitchWarning();

    (document.getElementById("load-defaults") as HTMLButtonElement)?.addEventListener(
      DOM_EVENT_NAMES.CLICK,
      () => this.loadDefaultRules()
    );
    (document.getElementById("save-rules") as HTMLButtonElement)?.addEventListener(
      DOM_EVENT_NAMES.CLICK,
      () => this.saveRules()
    );
    (document.getElementById("reset-rules") as HTMLButtonElement)?.addEventListener(
      DOM_EVENT_NAMES.CLICK,
      () => this.resetToDefaults()
    );

    (document.getElementById("export-rules") as HTMLButtonElement)?.addEventListener(
      DOM_EVENT_NAMES.CLICK,
      () => this.exportRules()
    );
    (document.getElementById("export-defaults") as HTMLButtonElement)?.addEventListener(
      DOM_EVENT_NAMES.CLICK,
      () => this.exportDefaultRules()
    );
    (document.getElementById("file-input") as HTMLInputElement)?.addEventListener(
      DOM_EVENT_NAMES.CHANGE,
      e => this.handleFileImport(e)
    );

    const brandSelect = document.getElementById("filter-brand") as HTMLSelectElement;
    const countrySelect = document.getElementById("filter-country") as HTMLSelectElement;
    const urlPatternSelect = document.getElementById("filter-url-pattern") as HTMLSelectElement;
    const clearFiltersBtn = document.getElementById("clear-filters") as HTMLButtonElement;

    brandSelect?.addEventListener(DOM_EVENT_NAMES.CHANGE, async () => {
      const brand = brandSelect.value;
      const rules = await this.rulesManager.loadRules();
      if (rules) {
        this.monacoManager.updateCountryDropdown(brand, rules);
        this.monacoManager.updateUrlPatternDropdown(brand, "", rules);
        this.monacoManager.applyFilters(brand, "", "");
      }
    });

    countrySelect?.addEventListener(DOM_EVENT_NAMES.CHANGE, async () => {
      const brand = brandSelect?.value || "";
      const country = countrySelect.value;
      const rules = await this.rulesManager.loadRules();
      if (rules) {
        this.monacoManager.updateUrlPatternDropdown(brand, country, rules);
        this.monacoManager.applyFilters(brand, country, "");
      }
    });

    urlPatternSelect?.addEventListener(DOM_EVENT_NAMES.CHANGE, async () => {
      const brand = brandSelect?.value || "";
      const country = countrySelect?.value || "";
      const urlPattern = urlPatternSelect.value;
      this.monacoManager.applyFilters(brand, country, urlPattern);
    });

    clearFiltersBtn?.addEventListener(DOM_EVENT_NAMES.CLICK, () => {
      if (brandSelect) {
        brandSelect.value = "";
      }
      if (countrySelect) {
        countrySelect.value = "";
        countrySelect.disabled = true;
      }
      if (urlPatternSelect) {
        urlPatternSelect.value = "";
        urlPatternSelect.disabled = true;
      }
      this.monacoManager.clearFilters();
    });

    document.addEventListener(UI_EVENTS.TRIGGER_LASER_ANIMATION, () => {
      this.animationManager.shootLasers();
    });

    document.addEventListener(UI_EVENTS.ENSURE_EXAMPLES_EDITOR, () => {
      this.monacoManager.ensureExamplesEditor();
    });

    document.addEventListener(UI_EVENTS.UPDATE_EXAMPLE, (event: Event) => {
      const customEvent = event as CustomEvent;
      const action = customEvent.detail?.action || AUTOMATION_ACTIONS.FILL;
      this.updateExample(action);
    });
  }

  async initializeMonacoEditor(): Promise<void> {
    await this.monacoManager.initializeMonacoEditor();
  }

  private generateAnchorId(text: string, prefix: string): string {
    return `${prefix}_${text
      .toLowerCase()
      .replace(/[^\w\s-]/g, "")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .trim()}`;
  }

  private addAnchorsToHeadings(container: HTMLElement, prefix: string): void {
    const headings = container.querySelectorAll("h3, h4, h5, h6");
    headings.forEach(heading => {
      if (!heading.id) {
        const text = heading.textContent?.trim() || "";
        if (text) {
          heading.id = this.generateAnchorId(text, prefix);
        }
      }
    });
  }

  private async loadLayoutFragments(): Promise<void> {
    const load = async (containerId: string, filePath: string, prefix?: string): Promise<void> => {
      const res = await fetch(filePath);
      const html = await res.text();
      const container = document.getElementById(containerId);
      if (container) {
        container.innerHTML = html;
        if (prefix) {
          this.addAnchorsToHeadings(container, prefix);
        }
      }
    };

    await Promise.all([
      load("header-container", "rules-editor/header.html"),
      load("navigation-container", "rules-editor/navigation.html"),
      load("editor-container", "rules-editor/editor-section.html"),
      load("import-export-container", "rules-editor/import-export-section.html"),
      load("documentation-container", "rules-editor/documentation.html", "documentation"),
      load("user-guide-container", "rules-editor/user-guide.html", "user-guide"),
    ]);
    await this.injectValidationLogger();
  }

  private async waitForEditorContainers(): Promise<void> {
    const exists = () =>
      document.getElementById("monaco-editor") &&
      document.getElementById("editor-row") &&
      document.getElementById("monaco-action-snippet");

    if (exists()) {
      return;
    }

    await new Promise<void>(resolve => {
      const observer = new MutationObserver(() => {
        if (exists()) {
          observer.disconnect();
          resolve();
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    });
  }

  private async injectValidationLogger(): Promise<void> {
    const logHost = document.getElementById("error-log");
    if (!logHost) {
      return;
    }

    let collapsed = true;
    const headerBtn = logHost.querySelector("#toggle-error-log-btn") as HTMLButtonElement | null;
    let errorCount = 0;
    const setLabel = (): void => {
      if (!headerBtn) {
        return;
      }
      if (errorCount === 0) {
        headerBtn.textContent = "No errors";
        headerBtn.disabled = true;
        headerBtn.setAttribute("aria-expanded", "false");
        headerBtn.setAttribute("disabled", "true");
        logHost.classList.add("collapsed");
      } else {
        headerBtn.disabled = false;
        headerBtn.textContent = collapsed ? "Expand" : "Collapse";
        headerBtn.setAttribute("aria-expanded", String(!collapsed));
      }
    };
    if (headerBtn) {
      setLabel();
      headerBtn.addEventListener(DOM_EVENT_NAMES.CLICK, () => {
        collapsed = !collapsed;
        logHost.classList.toggle("collapsed", collapsed);
        setLabel();
      });
    }

    const body = logHost.querySelector(".error-log-body");
    if (!body) {
      return;
    }

    let logCounter = 0;
    let totalErrors = 0;

    const extractMethodFromMessage = (msg: string): string | undefined => {
      const m = msg.match(/^\[rules-validation\]\s*\[([^\]]+)\]\s*/i);
      return m?.[1];
    };

    const getCallerName = (): string | undefined => {
      try {
        throw new Error();
      } catch (e: unknown) {
        const stack = (e as Error).stack || "";
        const lines = stack.split("\n").map(l => l.trim());
        for (const line of lines.slice(2)) {
          if (/rules-editor\/.+/.test(line)) {
            continue;
          }
          const match = line.match(/^at\s+([^\s(]+).*$/);
          const name = match?.[1];
          if (
            name &&
            name !== "console.error" &&
            name !== "console.warn" &&
            name !== "logInvalid"
          ) {
            return name;
          }
        }
      }
      return undefined;
    };

    const append = (
      _type: "error" | "warn",
      message: string,
      meta?: Record<string, unknown>,
      methodName?: string
    ) => {
      const item = document.createElement("div");
      item.className = "error-item";

      const when = new Date().toLocaleTimeString();
      const rawFirstLine = (message || "").split("\n")[0] || String(message);
      const headline = rawFirstLine.replace(/^\[rules-validation\]\s*(\[[^\]]+\]\s*)?/i, "").trim();

      const indexDiv = document.createElement("span");
      indexDiv.className = "error-index";
      indexDiv.textContent = `${++logCounter}.`;

      const content = document.createElement("div");
      content.className = "error-content";

      const header = document.createElement("div");
      header.className = "error-meta";
      const resolvedMethod = methodName || extractMethodFromMessage(rawFirstLine) || undefined;
      if (resolvedMethod) {
        const methodSpan = document.createElement("span");
        methodSpan.className = "error-method";
        methodSpan.textContent = `[${resolvedMethod}]`;
        header.appendChild(indexDiv);
        header.appendChild(methodSpan);
      } else {
        header.appendChild(indexDiv);
      }
      const msgSpan = document.createElement("span");
      msgSpan.className = "error-headline";
      msgSpan.textContent = headline;
      const timeSpan = document.createElement("span");
      timeSpan.className = "error-time";
      timeSpan.textContent = `[${when}]`;
      header.appendChild(msgSpan);
      header.appendChild(timeSpan);
      header.setAttribute("role", "button");
      header.setAttribute("tabindex", "0");

      const details = document.createElement("div");
      details.className = "error-details";
      item.classList.add("collapsed");
      const pre = document.createElement("pre");
      const rest = (message || "").split("\n").slice(1).join("\n").trim();
      pre.textContent = (rest ? rest + "\n" : "") + (meta ? JSON.stringify(meta, null, 2) : "");
      details.appendChild(pre);

      header.addEventListener(DOM_EVENT_NAMES.CLICK, () => {
        item.classList.toggle("collapsed");
      });
      header.addEventListener(DOM_EVENT_NAMES.KEYDOWN, e => {
        if ((e as KeyboardEvent).key === "Enter" || (e as KeyboardEvent).key === " ") {
          e.preventDefault();
          item.classList.toggle("collapsed");
        }
      });

      content.appendChild(header);
      content.appendChild(details);
      item.appendChild(content);
      (body as HTMLElement).appendChild(item);
      (body as HTMLElement).scrollTop = (body as HTMLElement).scrollHeight;

      totalErrors++;
      if (headerBtn) {
        if (totalErrors === 1) {
          collapsed = false;
          logHost.classList.remove("collapsed");
        }
        errorCount = totalErrors;
        setLabel();
      }
    };

    const originalError = console.error.bind(console);
    const originalWarn = console.warn.bind(console);

    console.error = (...args: unknown[]) => {
      try {
        if (typeof args[0] === "string" && args[0].toString().startsWith("[rules-validation]")) {
          const msg = String(args[0]);
          const method = extractMethodFromMessage(msg) || getCallerName();
          append("error", msg, (typeof args[1] === "object" && args[1]) as any, method);
        }
      } catch {
        /* noop */
      }
      originalError(...(args as any));
    };

    console.warn = (...args: unknown[]) => {
      try {
        if (typeof args[0] === "string" && args[0].toString().startsWith("[rules-validation]")) {
          const msg = String(args[0]);
          const method = extractMethodFromMessage(msg) || getCallerName();
          append("warn", msg, (typeof args[1] === "object" && args[1]) as any, method);
        }
      } catch {
        /* noop */
      }
      originalWarn(...(args as any));
    };
  }

  async loadDefaultRules(): Promise<void> {
    try {
      await this.rulesManager.loadDefaultRules(null);
      this.uiManager.editorSuccess("defaults load!");

      if (this.monacoManager.getEditor()) {
        const rules = await this.rulesManager.loadRules();
        if (rules) {
          this.monacoManager.setFullRules(rules);
          this.monacoManager.populateFilterDropdowns(rules);
          const filtered = this.monacoManager.filterRules(rules);
          this.monacoManager.setEditorValue(this.monacoManager.generateRulesCode(filtered));
          this.monacoManager.markAsSaved();
        }
      }
    } catch (error: any) {
      this.uiManager.editorError(error.message);
    }
  }

  async loadCurrentRules(): Promise<void> {
    try {
      await this.rulesManager.loadCurrentRules();
    } catch (error: any) {
      this.uiManager.editorError(error.message);
    }
  }

  async saveRules(): Promise<void> {
    try {
      const code = this.monacoManager.getEditorValue();
      const mergedRules = this.monacoManager.extractRulesFromCodeAndMerge(code);
      await this.rulesManager.saveRulesDirect(mergedRules);
      this.monacoManager.setFullRules(mergedRules);
      this.monacoManager.populateFilterDropdowns(mergedRules);
      const filtered = this.monacoManager.filterRules(mergedRules);
      this.monacoManager.setEditorValue(this.monacoManager.generateRulesCode(filtered));
      this.monacoManager.markAsSaved();
      this.uiManager.editorSuccess("save!");
    } catch (error: any) {
      this.uiManager.editorError(error.message);
    }
  }

  async resetToDefaults(): Promise<void> {
    if (
      confirm(
        `Are you sure you want to reset to default rules?\nThis will load defaults to editor and overwrite \nyour custom rules in localStorage.`
      )
    ) {
      try {
        await this.rulesManager.resetToDefaults();
        if (this.monacoManager.getEditor()) {
          const rules = await this.rulesManager.loadRules();
          if (rules) {
            this.monacoManager.setFullRules(rules);
            this.monacoManager.populateFilterDropdowns(rules);
            const filtered = this.monacoManager.filterRules(rules);
            this.monacoManager.setEditorValue(this.monacoManager.generateRulesCode(filtered));
            this.monacoManager.markAsSaved();
          }
        }
        this.uiManager.editorSuccess("reset!");
      } catch (error: any) {
        this.uiManager.editorError(error.message);
      }
    }
  }

  exportRules(): void {
    const rules = this.rulesManager.getCurrentRules();
    if (rules) {
      this.fileManager.exportRules(rules);
      this.uiManager.importExportSuccess("Rules exported!");
    }
  }

  exportDefaultRules(): void {
    const rules = this.rulesManager.getDefaultRules();
    if (rules) {
      this.fileManager.exportRules(rules);
      this.uiManager.importExportSuccess("Default rules exported!");
    }
  }

  async handleFileImport(event: Event): Promise<void> {
    try {
      const rules = await this.fileManager.handleFileImport(event);
      await this.rulesManager.saveRulesDirect(rules);
      if (this.monacoManager.getEditor()) {
        this.monacoManager.setFullRules(rules);
        this.monacoManager.populateFilterDropdowns(rules);
        const filtered = this.monacoManager.filterRules(rules);
        this.monacoManager.setEditorValue(this.monacoManager.generateRulesCode(filtered));
        this.monacoManager.markAsSaved();
      }
      this.uiManager.importExportSuccess("File imported!");
    } catch (error: any) {
      this.uiManager.importExportError(error.message);
    }
  }

  async updateUI(): Promise<void> {
    if (this.monacoManager.getEditor()) {
      const rules = await this.rulesManager.loadRules();
      if (rules) {
        this.monacoManager.setFullRules(rules);
        this.monacoManager.populateFilterDropdowns(rules);
        const filtered = this.monacoManager.filterRules(rules);
        this.monacoManager.setEditorValue(this.monacoManager.generateRulesCode(filtered));
        this.monacoManager.markAsSaved();
        setTimeout(() => {
          this.monacoManager.updateSaveButtonState();
        }, 100);
      }
    }
  }

  checkConstantsLoaded(): void {
    this.uiManager.checkConstantsLoaded();
  }

  updateExample(action: string): void {
    const examplesEditor = this.monacoManager.getExamplesEditor();
    if (!examplesEditor) {
      return;
    }

    examplesEditor.setValue(this.getExampleCode(action));
  }

  private getExampleCode(action: string): string {
    const header = "import { FieldAction, FormAutomationRules } from '@types';\n\n";
    const examples = ACTION_EXAMPLES;

    return header + (examples[action] || examples["fill"]);
  }
}

document.addEventListener(DOM_EVENT_NAMES.DOM_CONTENT_LOADED, () => {
  new RulesConfigManager();
});
