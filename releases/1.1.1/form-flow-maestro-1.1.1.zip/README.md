# Form Flow Maestro (Chrome Extension)

Rules-driven capture and autofill for complex forms. Configure per brand/country/step and execute reliable form automation.

See also: [INSTALL.md](./INSTALL.md) for teammate installation and usage instructions.

## Chrome Extension Architecture

### Overview

A Chrome extension is essentially a web application that runs within the Chrome browser environment. This extension follows the modern Manifest V3 architecture with clear separation of concerns.

### Core Components

#### 1. **manifest.json** (Required)

The manifest file is the heart of every Chrome extension. It defines:

- Extension metadata (name, version, description)
- Permissions and host access
- Component file references
- Icons and UI elements

#### 2. **Background Script (Service Worker) - `state-manager.bundle.js`**

- **Purpose**: Persistent logic, state management, cross-tab coordination
- **Runs**: In the background, even when no tabs are open
- **Access**: All Chrome APIs, storage, tabs management
- **Lifecycle**: Event-driven, can be dormant to save resources

#### 3. **Content Scripts - `page-controller.bundle.js`**

- **Purpose**: Interact with web page DOM, manipulate page content
- **Runs**: Inside web pages that match the specified patterns
- **Access**: Page DOM, limited Chrome APIs
- **Isolation**: Runs in isolated world (can't access page's JavaScript)

#### 4. **Popup UI - `popup.html/js/css`**

- **Purpose**: User interface when clicking extension icon
- **Files**: HTML, CSS, JavaScript
- **Lifecycle**: Opens/closes with user interaction

#### 5. **Rules Editor - `config.html`**

- **Purpose**: Advanced configuration interface for automation rules
- **Features**: Monaco Editor integration, TypeScript support, live validation
- **Access**: Via Settings button in popup or direct navigation to `config.html`
- **Capabilities**: Custom rule creation, import/export, documentation

### File Structure and Separation of Concerns

```
mule-chrome-plugin/
├── manifest.json                    # Extension configuration
├── dist/                           # Built extension files
│   ├── state-manager.bundle.js     # Background script (service worker)
│   ├── page-controller.bundle.js   # Content script
│   ├── popup.bundle.js             # Popup logic
│   ├── popup.html                  # Popup UI
│   ├── popup.css                   # Popup styles
│   └── config.html                 # Rules editor interface
├── modules/                         # Modular TypeScript architecture
│   ├── common/                     # Shared modules
│   │   ├── background/             # Service worker logic
│   │   ├── config/                 # Configuration management
│   │   ├── form-filling/           # Automation engine
│   │   └── validation/             # Type guards and validation
│   ├── popup/                      # Popup-specific modules
│   └── form-filling/               # Form automation logic
├── rules-editor/                   # Advanced rules configuration
│   ├── rules-editor.html          # Rules editor
│   └── documentation.html          # Comprehensive documentation
├── types/                          # TypeScript type definitions
└── icons/                         # Extension icons (16, 48, 128px)
```

### Communication Architecture

#### Message Passing System

```javascript
// Background to Content Script
chrome.tabs.sendMessage(tabId, { action: "CAPTURE_DATA" });

// Content Script to Background
chrome.runtime.sendMessage({ action: "CAPTURE_FORM_DATA", data: formData });

// Popup to Background
chrome.runtime.sendMessage({ action: "GET_CONFIG" });
```

#### Storage API

```javascript
// Store data persistently
chrome.storage.local.set({ key: value });

// Retrieve stored data
chrome.storage.local.get(["key"], result => {
  console.log(result.key);
});
```

### Permissions System

```json
"permissions": [
  "activeTab",    // Access to currently active tab
  "storage",      // Use chrome.storage API
  "tabs",         // Access to tabs API
  "scripting"     // Inject scripts into pages
],
"host_permissions": [
  "<all_urls>"    // Access to all websites
]
```

### Development and Testing

#### Loading for Development

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" (toggle in top right)
3. Click "Load unpacked"
4. Select the extension folder

#### Debugging Components

- **Background Script**: `chrome://extensions` > Inspect service worker
- **Content Script**: Regular page DevTools (Console tab)
- **Popup**: Right-click extension icon > Inspect popup

#### Release Workflow

The project includes automated release workflows using npm scripts and GitHub Actions:

**Available Scripts:**

- `npm run release` - Builds production version and creates zip file
- `npm run patch --message="Your commit message"` - Complete release workflow

**Release Process:**

1. **Build and Package**: `npm run release` creates the production build and zip file
2. **Create Release**: `npm run patch --message="Description of changes"` will:
   - Bump the patch version in `package.json`
   - Commit changes with your custom message
   - Create and push a git tag
   - Push to remote repository
   - Trigger GitHub Actions workflow to create a GitHub release

**GitHub Actions Integration:**

- Automatically triggered on tag push (e.g., `v1.0.4`)
- Builds production version with obfuscation
- Creates `mule-plugin.zip` distribution file
- Publishes GitHub release with installation instructions

**Example Usage:**

```bash
# Build and create zip file
npm run release

# Create a new patch release
npm run patch --message="Fix dropdown selection issue"
```

## How to Use

### Step 1: Configure the Extension

1. Click the extension icon in Chrome toolbar
2. Select your **Country** from the dropdown (e.g., "Mexico", "Czech Republic")
3. Choose additional options if available (Environment, Scoring)
4. **Enable Auto-capture** (optional): Check the "Enable Auto-capture" checkbox to automatically capture data when the capture page is refreshed and data is outdated
5. Configuration is automatically saved

### Step 2: Capture Data from Source Page

1. Navigate to a **data source page** (e.g., customer details page)
2. Click **"Capture Form Data"** button in the popup (or enable auto-capture for automatic capture on refresh)
3. The extension will automatically detect and capture:
   - Personal information (SSN, email, phone)
   - Address details
   - All form field data
4. Success is indicated by:
   - The popup showing captured data
   - **Extension icon turning green** in the Chrome toolbar
5. **Visual Feedback**: The extension icon provides real-time status:
   - **Yellow/Warning**: Data is outdated (SSN mismatch) - appears immediately on refresh
   - **Green/Success**: Data is up-to-date - appears after autocapture completes (~0.5-1.1s)
   - **Gray/Neutral**: No data captured yet
   - **Red/Error**: Error during capture

### Step 3: Automatic Form Filling

1. Navigate to the target form page
2. The extension will automatically detect the page and fill forms based on:
   - **Detected brand** (Provident, Creditea, etc.)
   - **Country-specific rules**
   - **Form step detection** (login, customer details, address, etc.)
3. Watch as fields are automatically populated and dropdowns are selected

### Step 4: Advanced Configuration (Optional)

1. Click the **⚙️ Settings** button in the popup
2. This opens the **Rules Editor** for advanced customization
3. Modify automation rules, add custom actions, or import/export configurations
4. Changes take effect immediately during the filling phase

## App Mode Detection

The extension automatically detects whether the localhost app is running in:

- **Provident mode**: Detected by finding a div with class containing "provident"
- **creditea mode**: Detected by finding a div with class containing "creditea"

Detection occurs by checking the selector: `.page-container .page-wrapper .page-header .container`

## Form Filling Logic

### Login Page (`/loan-app/login`)

#### When page contains "Please, sign up!":

- Fills all fields (except email) with "test"
- Fills email field with captured email value

#### When page contains "Do we know each other?":

- Fills field named "SSN" with captured SSN value
- Fills field named "msisdn" with type "tel" with captured phone number

### Customer Contacts Page (`/loan-app/loan/customer-contacts`)

#### When page contains "Please, complete your registration":

- Fills all fields named "email" with captured email value
- Fills all fields named "password" with "Qwerty123!"
- Fills all fields named "passwordConfirm" with "Qwerty123!"

### Customer Address Page (`/loan-app/loan/customer-address`)

- Fills address-related fields with captured data
- Handles custom dropdown selectors
- Sets residential status and address components

## Captured Data

The extension captures data from the following fields on the Data Capture page:

- **SSN**: First text input in `.divDataWrapper .divData.visible .contentValues`
- **Email**: Fields with values containing "@fakemail.mx" or email input types
- **Phone Number**: Field with ID "mx-msisdn" or mobile/tel input types
- **All form fields**: Comprehensive capture of all form elements for flexibility

## Troubleshooting

### Extension Won't Load

1. Check that the extension is enabled in `chrome://extensions/`
2. Ensure all files are in the `chrome-extension` folder
3. Check browser console for errors
4. Verify manifest.json syntax is valid

### Data Not Being Captured

1. Ensure configuration is saved
2. Check that you're on the Mule Injection page with expected HTML structure
3. Verify the extension has necessary permissions
4. Check content script console for errors

### Forms Not Being Filled

1. Verify you're on localhost with correct URL paths
2. Ensure the page contains expected text content
3. Check that the form has class "loan-form"
4. Confirm data was captured (visible in extension popup)

### Permission Issues

1. Check that host permissions include the target sites
2. Verify scripting permission is granted
3. Reload the extension after permission changes

## Technical Requirements

### Browser Compatibility

- **Chrome**: Full support (primary target)
- **Edge**: Should work (Chromium-based)
- **Opera**: Should work (Chromium-based)
- **Firefox**: Not supported (different extension API)
- **Safari**: Not supported (different extension API)

### Manifest V3 Features

- Service workers instead of background pages
- Enhanced security model
- Declarative permissions
- Limited remote code execution

### Development Requirements

- Chrome browser with developer mode enabled
- Node.js and npm for building
- TypeScript knowledge for advanced customization
- Basic understanding of JavaScript, HTML, CSS
- Familiarity with Chrome Extension APIs
- Access to target test environments

### Modern Architecture Features

- **TypeScript**: Full type safety and modern JavaScript features
- **Modular Design**: Clean separation of concerns with reusable modules
- **Webpack Build**: Optimized bundling with tree-shaking
- **Monaco Editor**: Professional code editing experience in rules editor
- **Automated Testing**: Built-in validation and error handling
- **GitHub Actions**: Automated builds and releases

## Security Considerations

### Content Security Policy

- No inline scripts in HTML files
- Limited eval() usage
- Restricted remote script loading
- All scripts must be local files

### Permission Model

- Users see exactly what permissions are requested
- Host permissions are separate from API permissions
- Optional permissions can be requested at runtime

### Data Handling

- Local storage only (chrome.storage.local)
- No data transmitted to external servers
- Sensitive form data handled securely

## File Structure

```
mule-chrome-plugin/
├── manifest.json                    # Extension configuration
├── dist/                           # Built extension files
│   ├── state-manager.bundle.js     # Service worker
│   ├── page-controller.bundle.js   # Content script
│   ├── popup.bundle.js             # Popup logic
│   ├── popup.html                  # Popup interface
│   ├── popup.css                   # Popup styles
│   └── config.html                 # Rules editor
├── modules/                         # Modular TypeScript architecture
│   ├── common/                     # Shared modules
│   ├── popup/                      # Popup-specific modules
│   └── form-filling/               # Form automation logic
├── rules-editor/                   # Advanced configuration
│   ├── rules-editor.html          # Rules editor interface
│   └── documentation.html          # Comprehensive docs
├── types/                          # TypeScript definitions
├── icons/                         # Extension icons (16, 48, 128px)
│   ├── icon16.png                 # 16x16 icon
│   ├── icon48.png                 # 48x48 icon
│   ├── icon128.png                # 128x128 icon
│   └── [status variants]         # Success, warning, error, neutral
└── README.md                      # This file
```

## API Usage

### Chrome APIs Used

- `chrome.runtime` - Messaging and lifecycle events
- `chrome.tabs` - Tab management and querying
- `chrome.storage` - Data persistence
- `chrome.scripting` - Script injection
- `chrome.action` - Extension icon and popup management

### Content Script Limitations

- Cannot access `chrome.tabs` directly
- Cannot access `chrome.storage` directly
- Must communicate with background script via message passing
- Runs in isolated world from page scripts

## License

This extension is provided "as is" for educational and personal use. Modify and distribute according to your needs.
